CREATE PROCEDURE UpdateJobStatus(IN ComplainId VARCHAR(250), IN UpdateVal INT(10))
  BEGIN 
SET @ComplainId = ComplainId;
SET @StatusVal = UpdateVal;
SET @l_sql = CONCAT( 'UPDATE CustomerData SET Status=? WHERE ComplainNumber = ? ' );

PREPARE stmt1 FROM @l_sql;

EXECUTE stmt1 USING @StatusVal,@ComplainId;

DEALLOCATE PREPARE stmt1;

END;
