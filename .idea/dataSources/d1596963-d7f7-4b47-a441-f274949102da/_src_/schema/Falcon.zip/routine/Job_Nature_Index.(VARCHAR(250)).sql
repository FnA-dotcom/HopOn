CREATE PROCEDURE Job_Nature_Index(IN JobNatureName VARCHAR(250))
  SELECT Id FROM JobNature WHERE LTRIM(RTRIM(JobNature)) = LTRIM(RTRIM(JobNatureName));
