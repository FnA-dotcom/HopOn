CREATE PROCEDURE MobileDataAssignment(IN UserId VARCHAR(250))
  BEGIN
	SELECT  a.RegistrationNum,a.CustName,a.CellNo,ifnull(a.PhoneNo,'-'),a.Make,a.Model,a.Color,a.ChesisNo,
	b.JobType,a.Address,IFNULL(a.DeviceNo,'-'),IFNULL(a.Insurance,'-'),a.ComplainNumber 
 	FROM CustomerData a 
 	STRAIGHT_JOIN JobType b ON a.JobTypeIndex = b.Id 
 	STRAIGHT_JOIN Assignment c ON a.Id=c.ComplaintId AND c.AssignmentStatus=0
 	STRAIGHT_JOIN  MobileUsers d ON c.UserId=d.Id AND upper(trim(d.UserId))= UserId 
	WHERE a.Status=0;
END;
