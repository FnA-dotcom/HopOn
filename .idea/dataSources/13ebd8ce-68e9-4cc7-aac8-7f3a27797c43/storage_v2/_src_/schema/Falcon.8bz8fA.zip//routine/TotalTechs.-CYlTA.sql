CREATE PROCEDURE TotalTechs()
  BEGIN
SELECT count(*) FROM `MobileUsers` WHERE `Status` = 0;
END;

