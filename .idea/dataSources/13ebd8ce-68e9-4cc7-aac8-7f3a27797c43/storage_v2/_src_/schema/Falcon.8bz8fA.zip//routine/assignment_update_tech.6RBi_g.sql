CREATE PROCEDURE assignment_update_tech(IN UserId          INT(10), IN ComplaintId INT(10), IN TransferFlag INT(10),
                                        IN AssignmentIndex INT(10))
  BEGIN 
SET @UserId = UserId;
SET @ComplaintId = ComplaintId;
SET @TransferFlag = TransferFlag;
SET @AssignmentIndex = AssignmentIndex;
SET @l_sql = CONCAT( 'UPDATE Assignment SET UserId=?,TransferFlag=? WHERE  ComplaintId= ? AND Id = ? ' );

PREPARE stmt1 FROM @l_sql;

EXECUTE stmt1 USING @UserId,@TransferFlag,@ComplaintId,@AssignmentIndex;

DEALLOCATE PREPARE stmt1;

END;

