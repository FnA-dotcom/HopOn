CREATE PROCEDURE TotalJobsNumber()
  SELECT TotalCount from TotalJobsHand;

