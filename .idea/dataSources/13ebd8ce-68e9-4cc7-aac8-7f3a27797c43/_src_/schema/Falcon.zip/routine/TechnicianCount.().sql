CREATE PROCEDURE TechnicianCount()
  BEGIN
SELECT count(*) FROM MobileUsers;
END;
