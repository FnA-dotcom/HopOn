CREATE PROCEDURE TotalLogOut()
  BEGIN
SELECT count(*) FROM `MobileUsers` WHERE UserId NOT IN (SELECT UserId FROM LoginTrail WHERE UserType = 'M') AND `Status` = 0;

END;
