CREATE PROCEDURE LoginandOnline()
  BEGIN
	Select Count(*) From LoginTrail  Where Status='0' And UserType ='M'
and UserId in (Select DISTINCT(UserId) from TechnicianLoginTrail where `Status`='0' and LoginFlag in ('OnlineAgain','LogIn'));
END;
