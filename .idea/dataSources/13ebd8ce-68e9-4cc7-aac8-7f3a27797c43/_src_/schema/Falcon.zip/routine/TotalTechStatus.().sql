CREATE PROCEDURE TotalTechStatus()
  BEGIN
-- Select a.Id, a.UserName, ifnull(b.Cnt,0) Assigned, ifnull(c.Cnt,0) Picked, ifnull(d.Cnt,0) Completed, ifnull(e.Cnt,0) Postpond, ifnull(f.Cnt,0) Canceled,a.UserId
-- From MobileUsers a
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 0 And AssignmentStatus = 0 Group By UserId) b ON a.Id = b.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 1  Group By UserId) c ON a.Id = c.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 6  Group By UserId) d ON a.Id = d.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 7  Group By UserId) e ON a.Id = e.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 8  Group By UserId) f ON a.Id = f.UserId 
-- WHERE a.Status=0 Order by a.UserName;
Select a.Id, a.UserName, ifnull(b.Cnt,0) Assigned, ifnull(c.Cnt,0) Picked, ifnull(d.Cnt,0) Completed, ifnull(e.Cnt,0) Postpond, ifnull(f.Cnt,0) Canceled,a.UserId
From MobileUsers a
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 0 group by userid, ComplaintId) x group by x.userid) b ON a.Id = b.UserId
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 1 group by userid, ComplaintId) x group by x.userid) c ON a.Id = c.UserId 
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 6 group by userid, ComplaintId) x group by x.userid) d ON a.Id = d.UserId
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 7 group by userid, ComplaintId) x group by x.userid) e ON a.Id = e.UserId 
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 8 group by userid, ComplaintId) x group by x.userid) f ON a.Id = f.UserId 
WHERE a.Status=0 Order by a.UserName;
END;
