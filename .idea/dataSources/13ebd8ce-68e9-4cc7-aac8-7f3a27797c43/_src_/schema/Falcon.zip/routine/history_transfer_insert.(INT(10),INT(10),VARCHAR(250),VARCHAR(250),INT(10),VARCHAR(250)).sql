CREATE PROCEDURE history_transfer_insert(IN ComplainId   INT(10), IN TechId INT(10), IN TransferBy VARCHAR(250),
                                         IN TransferDate VARCHAR(250), IN Status INT(10), IN CreatedDate VARCHAR(250))
  BEGIN
SET @ComplainId = ComplainId;
SET @TechId = TechId;
SET @TransferBy = TransferBy;
SET @TransferDate = TransferDate;
SET @Status = Status;
SET @CreatedDate = CreatedDate;

SET @l_sql = CONCAT( 'INSERT INTO TransferHistory (ComplainId, PreviousTechId, TransferBy, TransferDate, Status, CreatedDate) VALUES 
						(?,?,?,?,?,?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @ComplainId, @TechId, @TransferBy , @TransferDate , @Status, @CreatedDate;

DEALLOCATE PREPARE stmt;
END;
