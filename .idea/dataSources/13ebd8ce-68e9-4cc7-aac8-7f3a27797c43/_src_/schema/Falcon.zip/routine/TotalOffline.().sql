CREATE PROCEDURE TotalOffline()
  BEGIN
SELECT count(*) FROM `TechnicianLoginTrail` where LoginFlag = 'Offline';

END;
