CREATE PROCEDURE TotalOnline()
  BEGIN
Select Count(*) From LoginTrail  Where Status='0' And UserType ='M';
END;
