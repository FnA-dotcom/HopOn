CREATE PROCEDURE AssignmentCount(IN TechnicianId INT(10))
  BEGIN
-- SELECT count(*) FROM Assignment WHERE UserId=TechnicianId AND AssignmentStatus=0 AND ComplaintStatus NOT IN (5,6,7,8);
SELECT count(*) FROM Assignment WHERE UserId=TechnicianId AND ComplaintStatus = 0;
 END;
