CREATE PROCEDURE radius_check()
  SELECT Radius,FalconRadius,FalconLat,FalconLon FROM RadiusCheck;
