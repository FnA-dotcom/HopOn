CREATE PROCEDURE Insertion_of_Jobs(IN RegistrationNumber VARCHAR(250), IN CustomerName VARCHAR(250),
                                   IN CellNumber         VARCHAR(250), IN PhoneNumber VARCHAR(250),
                                   IN Make               VARCHAR(250), IN Model VARCHAR(250), IN Color VARCHAR(250),
                                   IN ChassisNumber      VARCHAR(250), IN Address VARCHAR(250), IN JobTypeIndex INT(10),
                                   IN DeviceNumber       VARCHAR(250), IN Insurance VARCHAR(250),
                                   IN JobNatureIndex     INT(10), IN Latitude VARCHAR(250), IN Longtitude VARCHAR(250),
                                   IN JobNumber          VARCHAR(250), IN STATUS INT(10), IN CreatedDate VARCHAR(255))
  BEGIN
SET @RegistrationNumber = RegistrationNumber;
SET @CustomerName = CustomerName;
SET @CellNumber = CellNumber;
SET @PhoneNumber = PhoneNumber;
SET @Make = Make;
SET @Model = Model;
SET @Color = Color;
SET @ChassisNumber = ChassisNumber;
SET @Address = Address;
SET @JobTypeIndex = JobTypeIndex;
SET @DeviceNumber = DeviceNumber;
SET @Insurance = Insurance;
SET @JobNatureIndex = JobNatureIndex;
SET @Latitude = Latitude;
SET @Longtitude = Longtitude;
SET @JobNumber = JobNumber;
SET @Status = STATUS;
SET @CreatedDate = CreatedDate;


SET @l_sql = CONCAT( 'INSERT INTO CustomerData (RegistrationNum, CustName, CellNo, PhoneNo, Make, Model, Color, ChesisNo, Address, JobTypeIndex, DeviceNo, Status, 
						CreatedDate, Insurance, ComplainNumber, JobNatureIndex, Latitude, Longtitude,ReAssigned)
						VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @RegistrationNumber, @CustomerName, @CellNumber , @PhoneNumber , @Make, @Model , @Color , @ChassisNumber , @Address , 
		   @JobTypeIndex , @DeviceNumber , @Status, @CreatedDate, @Insurance , @JobNumber, @JobNatureIndex , @Latitude, @Longtitude;

DEALLOCATE PREPARE stmt;
END;

