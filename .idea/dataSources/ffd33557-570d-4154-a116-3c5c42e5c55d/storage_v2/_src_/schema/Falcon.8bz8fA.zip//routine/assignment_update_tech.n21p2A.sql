CREATE PROCEDURE assignment_update_tech(IN UserId INT(10), IN ComplaintId INT(10))
  BEGIN 
SET @UserId = UserId;
SET @ComplaintId = ComplaintId;
SET @l_sql = CONCAT( 'UPDATE Assignment SET UserId=? WHERE  ComplaintId= ? ' );

PREPARE stmt1 FROM @l_sql;

EXECUTE stmt1 USING @UserId,@ComplaintId;

DEALLOCATE PREPARE stmt1;

END;

