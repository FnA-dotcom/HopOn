CREATE PROCEDURE TotalTechs(IN Param1 INT(10))
  BEGIN
IF(Param1 = -1)
THEN
  SELECT count(*) FROM `MobileUsers` WHERE `Status` = 0;
ELSE
  SELECT count(*) FROM `MobileUsers` WHERE `Status` = 0 AND CityIndex = Param1;
END IF;
END;

