CREATE PROCEDURE AssignedJobs(IN Param1 INT(10))
  BEGIN

-- SELECT count(*) FROM CustomerData a 
-- STRAIGHT_JOIN Assignment b ON a.Id = b.ComplaintId AND b.ComplaintStatus NOT IN (6,7,8)
-- AND b.Id = (SELECT MAX(x.Id) FROM Assignment x WHERE x.ComplaintId = b.ComplaintId) AND
-- date_format(b.CreatedDate,'%Y-%m-%d') =  DATE_FORMAT(NOW(),'%Y-%m-%d');
IF (Param1 = -1)
THEN
	SELECT count(*) FROM CustomerData a 
	STRAIGHT_JOIN Assignment b ON a.Id = b.ComplaintId
	AND b.Id = (SELECT MAX(x.Id) FROM Assignment x WHERE x.ComplaintId = b.ComplaintId) AND
	date_format(b.CreatedDate,'%Y-%m-%d') =  DATE_FORMAT(NOW(),'%Y-%m-%d');
ELSE
		SELECT count(*) FROM CustomerData a 
	STRAIGHT_JOIN Assignment b ON a.Id = b.ComplaintId
	AND b.Id = (SELECT MAX(x.Id) FROM Assignment x WHERE x.ComplaintId = b.ComplaintId) AND
	date_format(b.CreatedDate,'%Y-%m-%d') =  DATE_FORMAT(NOW(),'%Y-%m-%d') AND a.CityIndex = Param1;
END IF;

END;

