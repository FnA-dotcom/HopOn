CREATE PROCEDURE Insertion_of_History_of_Location_Change(IN RegistrationNumber VARCHAR(250),
                                                         IN CustomerName       VARCHAR(250),
                                                         IN PRELatitude        VARCHAR(250),
                                                         IN PRELongtitude      VARCHAR(250),
                                                         IN CURRLatitude       VARCHAR(250),
                                                         IN CURRLongtitude     VARCHAR(250), IN CityIndexVar INT(10),
                                                         IN ComplainIdVar      INT(10))
  BEGIN
SET @RegistrationNumber = RegistrationNumber;
SET @CustomerName = CustomerName;
SET @PRELatitude = PRELatitude;
SET @PRELongtitude = PRELongtitude;
SET @CURRLatitude = CURRLatitude;
SET @CURRLongtitude = CURRLongtitude;
SET @CityIndexVar = CityIndexVar;
SET @ComplainIdVar = ComplainIdVar;

SET @l_sql = CONCAT( 'INSERT INTO ChangeLocationHistory (RegistrationNum, CustomerName,PrevLatitude,PrevLongitude,LatestLatitude,LatestLongitude,ComplainId,Status,CreatedDate)
						VALUES (?,?,?,?,?,?,?,0,NOW()) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @RegistrationNumber, @CustomerName, @PRELatitude, @PRELongtitude, @CURRLatitude, @CURRLongtitude, @ComplainIdVar;

DEALLOCATE PREPARE stmt;
END;

