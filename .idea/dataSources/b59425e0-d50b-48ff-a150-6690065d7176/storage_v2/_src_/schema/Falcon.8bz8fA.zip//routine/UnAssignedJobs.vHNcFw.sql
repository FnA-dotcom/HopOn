CREATE PROCEDURE UnAssignedJobs()
  BEGIN
SELECT count(*) FROM CustomerData WHERE AssignStatus = 0;

END;

