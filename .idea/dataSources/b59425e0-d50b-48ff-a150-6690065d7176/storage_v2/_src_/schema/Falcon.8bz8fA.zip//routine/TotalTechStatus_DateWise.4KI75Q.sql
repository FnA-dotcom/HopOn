CREATE PROCEDURE TotalTechStatus_DateWise(IN StartDate VARCHAR(255), IN EndDate VARCHAR(200))
  BEGIN
-- Select a.Id, a.UserName, ifnull(b.Cnt,0) Assigned, ifnull(c.Cnt,0) Picked, ifnull(d.Cnt,0) Completed, ifnull(e.Cnt,0) Postpond, ifnull(f.Cnt,0) Canceled,a.UserId
-- From MobileUsers a
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 0 And AssignmentStatus = 0 AND CreatedDate BETWEEN StartDate AND EndDate Group By UserId) b ON a.Id = b.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 1  AND CreatedDate BETWEEN StartDate AND EndDate Group By UserId) c ON a.Id = c.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 6  AND CreatedDate BETWEEN StartDate AND EndDate Group By UserId) d ON a.Id = d.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 7  AND CreatedDate BETWEEN StartDate AND EndDate Group By UserId) e ON a.Id = e.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From Assignment WHERE ComplaintStatus = 8  AND CreatedDate BETWEEN StartDate AND EndDate Group By UserId) f ON a.Id = f.UserId 
-- WHERE a.Status=0 Order by a.UserName;
-- Select a.Id, a.UserName, ifnull(b.Cnt,0) Assigned, ifnull(c.Cnt,0) Picked, ifnull(d.Cnt,0) Completed, ifnull(e.Cnt,0) Postpond, ifnull(f.Cnt,0) Canceled,a.UserId
-- From MobileUsers a
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 0 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) b ON a.Id = b.UserId
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 1 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) c ON a.Id = c.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 6 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) d ON a.Id = d.UserId
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 7 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) e ON a.Id = e.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 8 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) f ON a.Id = f.UserId 
-- WHERE a.Status=0 Order by a.UserName;
-- Select a.Id, a.UserName, ifnull(b.Cnt,0) Assigned, ifnull(c.Cnt,0) Picked, ifnull(d.Cnt,0) Completed, ifnull(e.Cnt,0) Postpond, ifnull(f.Cnt,0) Canceled,a.UserId
-- From MobileUsers a
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 0 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x,(select ComplaintId, max(id) cont From Assignment Group by ComplaintId) y Where x.ComplaintId=y.ComplaintId and x.cont=y.cont group by x.userid) b ON a.Id = b.UserId
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 1 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x,(select ComplaintId, max(id) cont From Assignment Group by ComplaintId) y Where x.ComplaintId=y.ComplaintId and x.cont=y.cont group by x.userid) c ON a.Id = c.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 6 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) d ON a.Id = d.UserId
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 7 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) e ON a.Id = e.UserId 
-- LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 8 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) f ON a.Id = f.UserId 
-- WHERE a.Status=0 Order by a.UserName;
Select a.Id, a.UserName, ifnull(b.Cnt,0) Assigned, ifnull(c.Cnt,0) Picked, ifnull(d.Cnt,0) Completed, ifnull(e.Cnt,0) Postpond, ifnull(f.Cnt,0) Canceled,a.UserId
From MobileUsers a
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 0 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x,(select ComplaintId, max(id) cont From Assignment Group by ComplaintId) y Where x.ComplaintId=y.ComplaintId and x.cont=y.cont group by x.userid) b ON a.Id = b.UserId
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus IN (1,2,3,4,5,10) AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x,(select ComplaintId, max(id) cont From Assignment Group by ComplaintId) y Where x.ComplaintId=y.ComplaintId and x.cont=y.cont group by x.userid) c ON a.Id = c.UserId 
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 6 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) d ON a.Id = d.UserId
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 7 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) e ON a.Id = e.UserId 
LEFT JOIN (Select UserId, Count(*) Cnt From (select userid, ComplaintId, max(id) cont From Assignment WHERE ComplaintStatus = 8 AND (CreatedDate BETWEEN StartDate AND EndDate) group by userid, ComplaintId) x group by x.userid) f ON a.Id = f.UserId 
WHERE a.Status=0 Order by a.UserName;
END;

