CREATE PROCEDURE TotalOffline(IN Param1 INT(10))
  BEGIN
-- SELECT count(*) FROM `TechnicianLoginTrail` where LoginFlag = 'Offline';
-- SELECT count(*) FROM `TechnicianLoginTrail` where LoginFlag = 'Offline' AND
-- CreatedDate = (SELECT max(x.CreatedDate) FROM TechnicianLoginTrail x );
-- SELECT IFNULL(count(*),0) FROM TechnicianLoginTrail a
-- WHERE 
-- a.LoginFlag = 'Offline' 
-- AND a.Id = (SELECT MAX(Id) FROM TechnicianLoginTrail x WHERE x.TechId = TechId)
-- Group By  a.TechId, a.LoginFlag;
-- SELECT COUNT(*) FROM TechnicianLoginTrail a, MobileUsers b, 
-- (SELECT TechId, MAX(Id) Id FROM TechnicianLoginTrail Group by TechId) x
-- Where 
-- a.TechId = b.UserId AND 
-- b.`Status` = 0 And 
-- a.LoginFlag = 'Offline' And 
-- a.TechId=x.TechId and 
-- a.Id=x.Id;
IF(Param1 = -1)
THEN
SELECT COUNT(*) FROM TechnicianLoginTrail a, MobileUsers b, 
(SELECT TechId, MAX(Id) Id FROM TechnicianLoginTrail Group by TechId) x
Where 
a.TechId = b.UserId AND 
b.`Status` = 0 And 
a.LoginFlag = 'Offline' And 
a.TechId=x.TechId and 
a.Id=x.Id;
ELSE
SELECT COUNT(*) FROM TechnicianLoginTrail a, MobileUsers b, 
(SELECT TechId, MAX(Id) Id FROM TechnicianLoginTrail Group by TechId) x
Where 
a.TechId = b.UserId AND 
b.Status = 0 And 
a.LoginFlag = 'Offline' And 
a.TechId=x.TechId and 
a.Id=x.Id AND 
CityIndex = Param1;
END IF;
END;

