CREATE PROCEDURE TotalLogOut(IN Param1 INT(10))
  BEGIN
IF(Param1 = -1)
THEN
  SELECT count(*) FROM `MobileUsers` WHERE UserId NOT IN (SELECT UserId FROM LoginTrail WHERE UserType = 'M') AND `Status` = 0;
ELSE
  SELECT count(*) FROM `MobileUsers` WHERE UserId NOT IN (SELECT UserId FROM LoginTrail WHERE UserType = 'M') AND `Status` = 0 AND CityIndex = Param1;
END IF;
END;

