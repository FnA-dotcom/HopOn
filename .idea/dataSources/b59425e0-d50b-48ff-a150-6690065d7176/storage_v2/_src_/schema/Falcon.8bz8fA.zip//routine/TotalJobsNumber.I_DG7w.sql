CREATE PROCEDURE TotalJobsNumber(IN p_CityIndex INT(10))
  SELECT TotalCount from TotalJobsHand WHERE CityIndex = p_CityIndex;

