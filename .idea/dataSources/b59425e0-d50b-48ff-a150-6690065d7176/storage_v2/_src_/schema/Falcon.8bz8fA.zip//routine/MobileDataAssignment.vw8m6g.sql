CREATE PROCEDURE MobileDataAssignment(IN UserId VARCHAR(250))
  BEGIN
-- 	SELECT  a.RegistrationNum,a.CustName,a.CellNo,ifnull(a.PhoneNo,'-'),a.Make,a.Model,a.Color,a.ChesisNo,
-- 	b.JobType,a.Address,IFNULL(a.DeviceNo,'-'),IFNULL(a.Insurance,'-'),a.ComplainNumber, a.Id ComplainId ,d.Id TechId,
-- 	c.CreatedDate,NOW()
--  	FROM CustomerData a 
--  	STRAIGHT_JOIN JobType b ON a.JobTypeIndex = b.Id 
--  	STRAIGHT_JOIN Assignment c ON a.Id=c.ComplaintId AND c.AssignmentStatus=0 AND c.ComplaintStatus NOT IN (5,6,7,8) AND c.Id = (SELECT MAX(x.Id) FROM Assignment x WHERE x.ComplaintId = c.ComplaintId)
--  	STRAIGHT_JOIN  MobileUsers d ON c.UserId=d.Id AND upper(trim(d.UserId))= UserId ;

	SELECT  a.RegistrationNum,a.CustName,a.CellNo,ifnull(a.PhoneNo,'-'),a.Make,a.Model,a.Color,a.ChesisNo,
	b.JobType,a.Address,IFNULL(a.DeviceNo,'-'),IFNULL(a.Insurance,'-'),a.ComplainNumber, a.Id ComplainId ,d.Id TechId,
	c.CreatedDate,NOW(),a.Longtitude,a.Latitude
 	FROM CustomerData a 
 	STRAIGHT_JOIN JobType b ON a.JobTypeIndex = b.Id 
 	STRAIGHT_JOIN Assignment c ON a.Id=c.ComplaintId AND c.AssignmentStatus=0 AND c.ComplaintStatus NOT IN (5,6,7,8) AND c.Id = (SELECT MAX(x.Id) FROM Assignment x WHERE x.ComplaintId = c.ComplaintId)
 	STRAIGHT_JOIN  MobileUsers d ON c.UserId=d.Id AND upper(trim(d.UserId))= UserId ;
END;

