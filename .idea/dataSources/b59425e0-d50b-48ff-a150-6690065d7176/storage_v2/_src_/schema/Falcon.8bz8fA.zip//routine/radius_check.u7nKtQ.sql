CREATE PROCEDURE radius_check(IN p_CityIndex INT(10))
  SELECT Radius,FalconRadius,FalconLat,FalconLon FROM RadiusCheck WHERE CityIndex = p_CityIndex;

