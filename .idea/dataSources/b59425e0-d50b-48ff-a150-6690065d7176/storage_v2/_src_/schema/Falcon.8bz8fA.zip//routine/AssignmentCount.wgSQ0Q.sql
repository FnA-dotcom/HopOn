CREATE PROCEDURE AssignmentCount(IN TechnicianId INT(10))
  BEGIN
-- SELECT count(*) FROM Assignment WHERE UserId=TechnicianId AND AssignmentStatus=0 AND ComplaintStatus NOT IN (5,6,7,8);
-- SELECT count(*) FROM Assignment WHERE UserId=TechnicianId AND ComplaintStatus = 0;
-- SELECT count(*) FROM Assignment WHERE UserId=TechnicianId AND ComplaintStatus NOT IN (5,6,7,8);

SELECT  Count(*) Cnt FROM (SELECT userid, ComplaintId, max(id) cont FROM Assignment WHERE UserId=TechnicianId AND 
ComplaintStatus NOT IN (5,6,7,8) GROUP BY userid, ComplaintId) x,
(SELECT ComplaintId, max(id) cont FROM Assignment GROUP BY ComplaintId) y 
WHERE x.ComplaintId=y.ComplaintId AND x.cont=y.cont 
GROUP BY x.userid;
 END;

