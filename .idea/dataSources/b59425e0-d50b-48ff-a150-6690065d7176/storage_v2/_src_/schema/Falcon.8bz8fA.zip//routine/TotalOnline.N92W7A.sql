CREATE PROCEDURE TotalOnline(IN Param1 INT(10))
  BEGIN
IF(Param1 = -1)
THEN
   Select Count(*) From LoginTrail  Where Status='0' And UserType ='M';
ELSE
   Select Count(*) From LoginTrail  Where Status='0' And UserType ='M' AND CityIndex = Param1;
END IF;
END;

