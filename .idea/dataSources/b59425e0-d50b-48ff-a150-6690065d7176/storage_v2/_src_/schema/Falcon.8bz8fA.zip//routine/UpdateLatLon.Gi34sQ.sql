CREATE PROCEDURE UpdateLatLon(IN LatitudeVal VARCHAR(250), IN LongtitudeVal VARCHAR(250), IN ComplainId INT(10),
                              IN CityId      INT(10))
  BEGIN 
SET @LatitudeVal  = LatitudeVal ;
SET @LongtitudeVal  = LongtitudeVal ;
SET @ComplainId = ComplainId;
SET @CityId = CityId;
SET @l_sql = CONCAT( 'UPDATE CustomerData SET Latitude=?,Longtitude=? WHERE Id = ? AND CityIndex = ?' );

PREPARE stmt1 FROM @l_sql;

EXECUTE stmt1 USING @LatitudeVal,@LongtitudeVal,@ComplainId,@CityId;

DEALLOCATE PREPARE stmt1;

END;

